
public class UtilizadorExisteException extends Exception{
    public UtilizadorExisteException(String msg){
        super(msg);
    }
}
