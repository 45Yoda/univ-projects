
public class UtilizadorNaoExisteException extends Exception{
    public UtilizadorNaoExisteException(String msg){
        super(msg);
    }
}
