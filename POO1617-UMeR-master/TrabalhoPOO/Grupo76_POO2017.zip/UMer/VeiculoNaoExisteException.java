
public class VeiculoNaoExisteException extends Exception{
    
    public VeiculoNaoExisteException(String msg){
        super(msg);
    }
}
