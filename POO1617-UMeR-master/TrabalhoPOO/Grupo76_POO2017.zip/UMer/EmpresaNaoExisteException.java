

public class EmpresaNaoExisteException extends Exception{
    public EmpresaNaoExisteException(String msg){
        super(msg);
    }
}
