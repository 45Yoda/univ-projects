
public class VeiculoExisteException extends Exception{

  public VeiculoExisteException(String msg){
      super(msg);
  }
}
